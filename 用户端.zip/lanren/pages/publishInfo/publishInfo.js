// pages/publishInfo/publishInfo.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
    var orderId = options.orderId //options.orderId  "75335278053393"
    var idCard = options.idCard  //options.idCard  "43132120001207576X"
    var that = this
    this.setData({
      orderId: orderId
    })
    wx.request({
      url: 'http://47.104.191.228:8085/student/getInfo',
      data:{
        idCard:idCard
      },
      method:"GET",
      header:{
        "Accept":"application/json"
      },success(res){
        console.log(res)
        that.setData({
          publishInfo:res.data
        })
      }
    })
  },
  jb:function(e){
    var publishIdCard = this.data.publishInfo.idCard
    var orderId = this.data.orderId
    wx.navigateTo({
      url: "../jb/jb?publishIdCard=" + publishIdCard + "&orderId=" + orderId
    })

  }
})