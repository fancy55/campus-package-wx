// pages/mydl/mydl.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var app = getApp()
    var that = this
    var userInfo = app.globalData.userInfo
    var idCard = userInfo.idCard//userInfo.idCard
    wx.request({
      url: 'http://47.104.191.228:8085/publishPack/get/help',
      method:"GET",
      data:{
        qIdCard:idCard
      },
      header:{
        'content-type':'application/json'
      },
      success:function(res){
        console.log(res)
        that.setData({
          list:res.data
        })
      }
    })
  },
  daiLing:function(e){
    console.log(e)
    var index = e.currentTarget.dataset.index
    var ewm = this.data.list[index].ewm
    wx.navigateTo({
      url: 'ewm/ewm?ewm='+ewm,
    })
  },
  detailInfo: function (e) {
    console.log(e)
    var index = e.currentTarget.dataset.index
    var orderId = this.data.list[index].orderId
    var idCard = this.data.list[index].sidCard
    console.log(orderId)
    wx.navigateTo({
      url: '../../publishInfo/publishInfo?orderId=' + orderId + '&idCard=' + idCard,
    })
  },
})