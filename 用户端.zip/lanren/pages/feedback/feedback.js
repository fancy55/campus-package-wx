Page({
  data: {
    loading: false,
    phone: '',
    content: '',
  },
  formSubmit: function (e) {
    let _that = this;
    let content = e.detail.value.opinion;
    let phone = e.detail.value.contant;
    let regPhone = /^1[3578]\d{9}$/;
    if (content == "") {
      wx.showModal({
        title: '提示',
        content: '反馈内容不能为空!',
      })
      return false
    }
    if (phone == "") {
      wx.showModal({
        title: '提示',
        content: '手机号不能为空!',
      })
      return false
    }
    if (phone == "" && content == "") {
      wx.showModal({
        title: '提示',
        content: '反馈内容,手机号不能为空!',
      })
      return false
    }
    if (!regPhone.test(phone)) { //验证手机号或者邮箱的其中一个对 这个关系饶了俩小时^_^
      wx.showModal({
        title: '提示',
        content: '您输入的手机号有误!',
      })
      return false
    } else {
      this.setData({
        loading: true
      })
      wx.request({
        url: 'http://47.104.191.228:8085/feedback/insert',
        header: {
          'content-type': 'application/x-www-form-urlencoded'
        },
        data: {
          'content': content,
          'phone': phone

        },
        method: 'POST',
        success: function (res) {
          // let status = res.data.status;
          // if (status == 1) {
          //   _that.setData({
          //     loading: false,
          //     contact: '',
          //     contant: ''
          //   })
          
          //}
          console.log(res)
          console.log("feedback ok!")
        },
        fail: function () {
          console.log("意见反馈接口调用失败")
        },
        complete:function(){
          wx.showToast({
            title: '提交成功',
            icon: "success"
          })
          wx.navigateBack({
          })
        }
      })
    }
  },
  onLoad:function(){
  }
})