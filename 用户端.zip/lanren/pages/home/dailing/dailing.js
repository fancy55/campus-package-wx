// pages/home/dailing/dailing.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   this.setData({
     orderId:options.orderId
   })
   console.log(options)
  },
  submit: function(e){
    console.log(e)
    var orderId = this.data.orderId
    console.log(orderId)
    var value = e.detail.value
    let list = JSON.stringify({
      orderId: orderId,
      qnickname: value.qnickname,
      qphone:value.qPhone,
      qidCard: value.qidCard
    })
    console.log(list)
    wx.request({
      url: 'http://47.104.191.228:8085/packC/receive/help',
      data:{
        // "orderId": orderId,
        // "qnickname": value.qnickname,
        // "qphone": value.qPhone,
        // "qidCard": value.qidCard
        "orderId": orderId,
        "qidCard": value.qidCard,
        "qnickname": value.qnickname,
        "qphone": value.qPhone
      },
      header: {
        "Content-Type": "application/json"
      },
    method:"POST",
    dataType:"json",
    
    success(res){
      console.log("代领成功",res)
      wx.showToast({
        title: '成功',
      })
    }
   })
  }
 
})