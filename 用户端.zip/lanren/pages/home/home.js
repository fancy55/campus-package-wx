// pages/home/home.js
var util = require("../../utils/util.js")
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isHide:true,
    list:[],
    login:false
  },
 
  
  /**
   * 生命周期函数--监听页面加载
   */
  onShow: function (options) {
    var that = this
    this.requestlist().then((data) => { 
      data.forEach((item, index) => {
        var jzdate = item.endDate
        //console.log(jzdate)
        var date = util.formatDate(new Date())
        //console.log(date)
        if (jzdate < date) {
          //list.pop(item)
          console.log(true)
          console.log(item.orderId)
          that.compareDate(item.orderId)
        }
        else {
          console.log(false)
        }
      })
      
    })
    
  },
  compareDate:function(e){
    var orderId = e
    var that = this
    wx.request({
      url: 'http://47.104.191.228:8085/publishPack/no/use?orderId=' + orderId,
      method:"POST",
      // data:{
      //   "orderId":orderId
      // },
      header:{
        "Content-Type": "application/json"
      },
      success:function(res){
        console.log(res)
        that.requestlist()
      },
      fail:function(res){
        console.log(res)
      }
    })
  },
  requestlist:function(){
    var n = new Date()
    console.log(n)
    var app = getApp()
    var that = this
    var promise = new Promise((resolve, reject) => {
      wx.request({
        url: 'http://47.104.191.228:8085/publishPack/get/all/publish',
        method: 'POST',
        header: {
          "content-type": "application/x-www-form-urlencoded"
        },
        success: function (res) {
          console.log(res.data)
          that.setData({
            list: res.data
          })
          resolve(res.data)
        }
      });
    });
    return promise;
  },
  detailInfo:function(e){
    console.log(e)
    var index = e.currentTarget.dataset.index
    var orderId = this.data.list[index].orderId
    var idCard = this.data.list[index].sidCard
    console.log(orderId)
    wx.navigateTo({
      url: '../publishInfo/publishInfo?orderId='+orderId+'&idCard='+idCard,
    })
  },
  newPage: function (e) {
    var app = getApp()
    // if (userStatus == "login")
      wx.navigateTo({
        url: 'search/search',
      })
  },
  daiLing: function(e){
    var that = this
    var app = getApp()
    var status = app.globalData.status
    if(status!=1)
    wx.showModal({
      title: '提示',
      content: '您还不具备代领权限',
    })
    else
    wx.showModal({
      title: '提示',
      content: '确定要代领该快递吗',
      success(res) {
        if (res.confirm) {
          var index = e.currentTarget.dataset.index
          var orderId = that.data.list[index].orderId
          wx.navigateTo({
            url: 'dailing/dailing?orderId=' + orderId,
          })
        } else if (res.cancel) {
          console.log('用户取消代领该快递')
        }
      }
    })
   
 
  }
})