// pages/home/search/search.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  detailInfo: function (e) {
    console.log(e)
    var index = e.currentTarget.dataset.index
    var orderId = this.data.list[index].orderId
    var idCard = this.data.list[index].sidCard
    console.log(orderId)
    wx.navigateTo({
      url: '../../publishInfo/publishInfo?orderId=' + orderId + '&idCard=' + idCard,
    })
  },
  daiLing: function (e) {
    var that = this
    wx.showModal({
      title: '提示',
      content: '确定要代领该快递吗',
      success(res) {
        if (res.confirm) {
          var index = e.currentTarget.dataset.index
          var orderId = that.data.list[index].orderId
          wx.navigateTo({
            url: '../dailing/dailing?orderId=' + orderId,
          })
        } else if (res.cancel) {
          console.log('用户取消代领该快递')
        }
      }
    })


  },

  formSubmit: function (e) {
    var para = e.detail.value.para
    var that = this
    console.log(para)
    wx.request({
      url: 'http://47.104.191.228:8085/publishPack/receive/qPos',
      method: "POST",
      data: {//75328925404629
        para: para
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      success: function (res) {
        console.log(res)
        that.setData({
          list:res.data
        })
        // var array = res.data.publishPack[0]
        // that.setData({
        //   item: array
        // })
        // var item = that.data.item
        // console.log(item)
        // if (item) {
        //   that.setData({
        //     viewCourier: true
        //   })
        // }
      }
    })
  },
})