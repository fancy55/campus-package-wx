// pages/mine/myInfo/myInfo.js
var util = require("../../../utils/util.js")

Page({

  /**
   * 页面的初始数据
   */
  data: {
    photo:"",
    code:""
  },
//430781200012120524
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
    var app = getApp()
    var userInfo = app.globalData.userInfo
    console.log("用户信息", userInfo)
    this.setData({
      userInfo: userInfo,
      photo:userInfo.photo,
      phone:userInfo.phone
    })
  },
  changeAvatar:function(e){
    console.log("改变头像")
    var that = this
    var app = getApp()
    var photo1 = "userInfo.photo"
    wx.chooseImage({
      count:1,
      success: function(res) {
        var idCard = that.data.userInfo.idCard
        var ff = res.tempFilePaths
        console.log(res)
        // var url = res.tempFilePaths
        that.setData({
          photo:res.tempFilePaths
        })
        wx.uploadFile({
          url: 'http://47.104.191.228:8085/student/updatePhoto',
          filePath: res.tempFilePaths[0],
          name: 'file',
          header: {
            "Content-Type": "multipart/form-data",
            "Accept": "application/json"
          },
          formData: {
            'idCard': idCard
          }, success: function (res) {
            console.log(ff)
            console.log(ff[0])
            
            that.setData({
              [photo1]:ff
            })
            app.globalData.userInfo = that.data.userInfo
            console.log("修改后的用户信息", app.globalData.userInfo)
          }, fail: function (res) {
            console.log(res)
          }
        })
      },
    })
    // var idCard = this.data.userInfo.idCard
    // console.log("身份证", idCard)
    
  },
  inputNumber: function (e) {
    var phone = e.detail.value
    this.setData({
      phone: phone
    })
  },
  getNumber: function (e) {
    var phone = this.data.phone
    var that = this
    console.log(phone)
    wx.request({
      url: 'http://47.104.191.228:8085/send/' + phone,
      method: "get",
      header: {
        "Content-Type": "application/json;charset=UTF-8"
      },
      success: function (res) {
        console.log(res)
        that.setData({
          mycode: res.data.code
        })
      },
      fail: function (res) {
        console.log(res)
      }
    })
  },
  submitInfo: function(e){
    console.log(e)
    var that = this
    var app = getApp()
    
    if(e.detail.code){
    if(code==e.detail.value.code)
    that.subrequest(e.detail.value)
    else {
      wx.showModal({
        title: '提示',
        content: '验证码错误',
      })
    }
    }else
      this.subrequest(e.detail.value)
    
      
  },
  disabledInput: function(e){
    wx.showModal({
      title: '提示',
      content: '不能修改',
    })
  },
  subrequest:function(e){
    var app = getApp()
    var that = this
    var phone1 = "userInfo.phone"
    var sex1 = "userInfo.sex"
    var age1 = "userInfo.age"
    var nickname1 = "userInfo.nickname"
    var college1 = "userInfo.college"
    var major1 = "userInfo.major"
    var address1 = "userInfo.address"
    wx.request({
      url: 'http://47.104.191.228:8085/student/updateInfo',
      data: {
        "phone": e.phone,
        "sex": e.sex,
        "age": e.age,
        "idCard": e.idCard,
        "nickname": e.nickname,
        "college": e.college,
        "major": e.major,
        "address": e.address
      },
      method: "POST",
      header: {
        "Content-Type": "application/json;charset=UTF-8",
        "Accept": "text/plain"
      },
      success: function (res) {
        console.log(res.data)
        that.setData({
          [phone1]: e.phone,
          [sex1]: e.sex,
          [age1]: e.age,
          [nickname1]: e.nickname,
          [college1]: e.college,
          [major1]: e.major,
          [address1]: e.address
        })
        app.globalData.userInfo = that.data.userInfo
        console.log("修改后的用户信息", app.globalData.userInfo)
        wx.showToast({
          title: '修改成功',
        })
      }
    });
  }
})