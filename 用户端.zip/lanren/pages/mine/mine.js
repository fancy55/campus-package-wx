// pages/mine/mine.js


Page({

  /**
   * 页面的初始数据
   */
  data: {
   loginStatus:false,
   mine:"",
   isHide:true,
   userinfo:"",
   arrow:false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onShow: function (options) {
    var _this=this
    var app=getApp()
    var userInfo = app.globalData.userInfo
    console.log("用户已登录",userInfo)
    this.setData({
      userInfo:userInfo
    })
  },
  shouquan:function(res){
     wx.navigateTo({
       url: '../dlsq/dlsq',
     })
  },
  myInfo: function (res) {
    var app = getApp()
    var userInfo = app.globalData.userInfo
    console.log("lll",this.data.userinfo)
    wx.navigateTo({
      url: 'myInfo/myInfo',
    })
  },
  all:function(res){
    wx.navigateTo({
      url: '../all/all',
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    var that = this
    return {
      title: '校园快递通-便利你我他',
      path: '/pages/mine/mine?id=' + that.data.scratchId,
      success: function (res) {
        // 转发成功
      console.log("success")
        that.shareClick();
      },
      fail: function (res) {
        // 转发失败
        console.log(res)
      }
    }
  },
  person_information: function () {
    wx.navigateTo({
      url: '../zhgl/zhgl',
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  helpAndFeedback: function () {
    wx.navigateTo({
      url: '../../pages/feedback/feedback',
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  myKuaidi:function(){
    var arrowNow = !this.data.arrow
    this.setData({
      arrow:arrowNow
    })
    wx.navigateTo({
      url: '../../pages/myPage/myPage',
    })
  }
})