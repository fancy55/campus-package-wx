var releaseData = {
  list:""
}
module.exports = {
  releaseData:releaseData
}