// pages/publish/publish.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  // onLoad: function (options) {
   
  // },

  onShow: function (options) {
    var that = this
    this.requestlist().then((data) => {
      data.forEach((item, index) => {
        var jzdate = item.endDate
        //console.log(jzdate)
        var date = util.formatDate(new Date())
        //console.log(date)
        if (jzdate < date) {
          //list.pop(item)
          console.log(true)
          console.log(item.orderId)
          that.compareDate(item.orderId)
        }
        else {
          console.log(false)
        }
      })

    })

  },
  compareDate: function (e) {
    var orderId = e
    wx.request({
      url: 'http://47.104.191.228:8085/publishPack/no/use?orderId=' + orderId,
      method: "POST",
      // data:{
      //   "orderId":orderId
      // },
      header: {
        "Content-Type": "application/json"
      },
      success: function (res) {
        console.log(res)
        that.requestlist()
        // that.setData({
        //   list: list
        // })
      },
      fail: function (res) {
        console.log(res)
      }
    })
  },
  requestlist: function () {
    var app = getApp()
    var userInfo = app.globalData.userInfo
    var sIdCard = userInfo.idCard// userInfo.sIdCard
    var that = this
    var promise = new Promise((resolve, reject) => {
      wx.request({
        url: 'http://47.104.191.228:8085/publishPack/get/publish?sIdCard='+sIdCard,
        method: "GET",
        header: {
          "Content-Type": "application/json"
        },
        success: function (res) {
          console.log(res),
            that.setData({
              list: res.data
            })
        },
        fail: function (res) {
          console.log("更新" + res.data)
        }
      })
    });
    return promise;
  },
})