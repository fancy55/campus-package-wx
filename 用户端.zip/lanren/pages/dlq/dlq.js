// pages/dlq/dlq.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    viewBtn: true,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var app = getApp()
    var userInfo = app.globalData.userInfo
    var that = this
    wx.request({
      url: 'http://47.104.191.228:8085/packC/get/all/wait',
      data: {
        sPhone: userInfo.phone //userInfo.phone  "15873889873" 
      },
      method: "GET",
      header: {
        'Content-Type': 'application/json'
      },
      success: function (res) {
        console.log(res)
        that.setData({
          myKuaidi:res.data
        })
      },
      fail: function (res) {
        console.log(res)
      }
    })
  },

  refreshState: function (e) {
    var that = this
    var index = e.currentTarget.dataset.index
    var orderId = this.data.myKuaidi[index].orderId
    var qstatus = this.data.myKuaidi[index].qstatus
    console.log(e)
    if (qstatus == "1") {
    }
    else {
      wx.showModal({
        title: '提示',
        content: '确认已收到快递吗',
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
            console.log(orderId)
            wx.request({
              url: 'http://47.104.191.228:8085/packC/update/status?orderId='+orderId,
              method: "POST",
              data:{
                orderId:orderId
              },
              header: { 'Content-Type': 'application/json', 'Accept':'*/*' },
              success: function (res) {
                console.log(res)
                that.data.myKuaidi[index].qstatus = "1"
                that.setData({
                  myKuaidi: that.data.myKuaidi
                })
              }
            })
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    }

  },
  erweima: function (e) {
    var index = e.currentTarget.dataset.index
    var orderId = this.data.myKuaidi[index].orderId
    wx.navigateTo({
      url: '../dynamic/erweima/erweima?orderId='+orderId,
    })
  },
  release: function (e) {
    var index = e.currentTarget.dataset.index
    var orderId = this.data.myKuaidi[index].orderId
    var qpos = this.data.myKuaidi[index].qpos
    var sphone = this.data.myKuaidi[index].sphone
    var qjm = this.data.myKuaidi[index].qjm
  //   if (sstatus == "yes") {
  //     wx.showModal({
  //       title: '提示',
  //       content: '该快递已领取',
  //     })
  //   }
  //  else {
      wx.navigateTo({
        url: '../dynamic/release/release?orderId=' + orderId + '&qpos=' + qpos + '&sphone=' + sphone + '&qjm=' + qjm,
        })
    // }
  }

  ,
  lost: function (e) {
    var index = e.currentTarget.dataset.index
    var orderId = this.data.myKuaidi[index].orderId
    wx.navigateTo({
      url: '../dynamic/lost/lost?orderId=' + orderId,
    })
  }
})