// pages/dlsq/dlsq.js
var util = require("../../utils/util.js")
Page({

  /**
   * 页面的初始数据
   */
  data: {
     size:0,
     list:[],
     look:true

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var app = getApp()
    var that = this
    var idCard = app.globalData.userInfo.idCard
    //var idCard = "43132120001207576X"
    wx.request({
      url: 'http://47.104.191.228:8085/student/get/my/certification?idCard='+idCard,
      method:"GET",
      success:function(res){
        console.log("审核状态",res)
        // if(res.data!=null){
        app.globalData.status = res.data//[0].status
        if(res.data=="0"){
           that.setData({
             msg: "正在审核中",
             look: false
           })
        }
        if (res.data == "1") {
          that.setData({
            msg: "您已获得代领权限",
            look: false
          })
        }
        if (res.data == "-1") {
          that.setData({
            msg: "未通过，请重新上传",
            look: true
          })
        }
      }
    })
  },
  add:function(e){
    var that = this
    var size = this.data.size
    var list = this.data.list
   wx.chooseImage({
     count:4,
     success: function(res) {
       console.log(res)
       console.log(res.tempFilePaths.length)
       size += res.tempFilePaths.length
       res.tempFilePaths.forEach((item,index)=>{
         list.push(item)
       })
       
       console.log(size)
       that.setData({
         size:size,
         list: list
       })
     },
   })
  },
  shangchuan:function(e){
    var app = getApp()
    var idCard = app.globalData.userInfo.idCard
    var size = this.data.list.length
    var list = this.data.list
    let ll = JSON.stringify({
      "idCard": idCard,
      "date": util.formatDate(new Date())
    })
    console.log(ll)
    console.log("照片数",size)
    console.log("照片路劲",list)
    if(size!=4){
      wx.showModal({
        title: '提示',
        content: '照片数量不对哦',
      })
    }else{
      for(var i=0;i<list.length;i++){
        wx.uploadFile({
          url: 'http://47.104.191.228:8085/student/post/certification',
          filePath: list[i],
          name: 'file',
          header: {
            "Content-Type": "multipart/form-data",
            "Accept": "*/*"
          },
          formData:{
            "size":i+1,
            "msg":ll
          },success:function(res){
            console.log(res)
            if (i==3){
              wx.showToast({
                title: '提交成功'
              })
            }
          }
        })
      }
    }
  }
})