// pages/myPage/myPage.js
var util = require("../../utils/util.js")

Page({

  /**
   * 页面的初始数据
   */
  data: {
    password:"",
    pwdtrue:false,
    phone:""

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
// getPhoto:function(){
//   var that = this
//   wx.chooseImage({
//     count: 1,
//     success: function(res) {
//       console.log(res)
//       that.setData({
//         photo:res.tempFilePaths
//       })
//     },
//     fail: function(res) {
//       wx.showModal({
//         title: '提示',
//         content: '请重新上传！',
//       })
//     }
//   })
// },
getPwd:function(e){
  console.log(e)
  this.setData({
    password:e.detail.value
  })
},
confirmPassword:function(e){
  console.log(e)
  var repassword = e.detail.value
  var password = this.data.password
  if(password==repassword)
  this.setData({
    pwdtrue:false
  })
  else
  this.setData({
    pwdtrue:true
  })
},
inputNumber:function(e){
  var phone = e.detail.value
  this.setData({
    phone:phone
  })
},
getNumber:function(e){
  var phone = this.data.phone
  var that = this
  console.log(phone)
  wx.request({
    url: 'http://47.104.191.228:8085/send/'+phone,
    method: "get",
    header: {
      "Content-Type": "application/json;charset=UTF-8"
    },
    success:function(res){
      console.log(res)
      that.setData({
        mycode:res.data.code
      })
    },
    fail:function(res){
      console.log(res)
    }
  })
},
formSubmit:function(e){
  console.log(e)
  var nickname = e.detail.value.nickname
  var phone = e.detail.value.phone 
  var password = e.detail.value.password
  var idCard = e.detail.value.idCard
  var name = e.detail.value.name
  var code = e.detail.value.code
  var mycode = "12345"
  var date = util.formatDate(new Date())
  if(code==mycode)
  wx.request({
    url: 'http://47.104.191.228:8085/student/register',
    method:"POST",
    data:{
      "nickname":nickname,
      "phone":phone,
      "password":password,
      "idCard":idCard,
      "name":name,
      "date":date
    },
    header:{
      "Content-Type": "application/json"
    },
    success:function(res){
      console.log(res)
      wx.showToast({
        title: '成功',
      })
      setTimeout(function () {
        wx.navigateBack({
          delta: 1
        })
        wx.hideLoading()
      }, 2000)
    },
    fail:function(res){
      console.log(res)
    }
  })
  else{
    wx.showModal({
      title: '提示',
      content: '验证码错误',
    })
  }
}
})