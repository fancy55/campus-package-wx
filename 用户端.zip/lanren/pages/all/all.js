// pages/all/all.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    viewBtn: false,
    myKuaidi:null,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onShow: function (options) {
    var that = this
    var app = getApp()
   //var userInfo = app.globalData.userInfo
    //var sPhone = userInfo.phone
   wx.request({
     url: 'http://47.104.191.228:8085/packC/get/all',
     data:{
       sPhone:"15873889873"
     },
     method:"GET",
     header: {
       'Content-Type': 'application/json'
     },
     success:function(res){
       console.log(res)
       that.setData({
         myKuaidi:res.data
       })
       }
       
     ,
     fail:function(res){
       console.log(res)
     }
   })
  },
  changeStatus:function(e){
    console.log(e)
    var that = this
    var index = e.currentTarget.dataset.index
    var orderId = this.data.myKuaidi[index].orderId
    var qstatus = this.data.myKuaidi[index].qstatus;
    if(qstatus=="1"){
     wx.showModal({
       title: '提示',
       content: '该快递已被领取',
     })
    }else{
      wx.showModal({
        title: '提示',
        content: '确定领取该快递吗',
        success(res){
          if(res.confirm){
            console.log('用户点击确定')
            console.log(orderId)
            wx.request({
              url: 'http://47.104.191.228:8085/packC/update/status?orderId=' + orderId,
              method: "POST",
              data: {
                orderId: orderId
              },
              header: { 'Content-Type': 'application/json', 'Accept': '*/*' },
              success: function (res) {
                console.log(res)
                that.data.myKuaidi[index].qstatus = "1"
                that.setData({
                  myKuaidi: that.data.myKuaidi
                })
              }
            })
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    }

  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
 
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})