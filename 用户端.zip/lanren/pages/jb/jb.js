// pages/jb/jb.js
var util = require("../../utils/util.js")
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var orderId = options.orderId
    var publishIdCard = options.publishIdCard
    this.setData({
      publishIdCard: publishIdCard,//publishIdCard,"430781199812120524"
      orderId: orderId//orderId  "75335278053393"
    })
  },

  submitjb:function(e){
    console.log(e)
    var date = util.formatDate(new Date())
    var orderId = this.data.orderId
    var publishIdCard = this.data.publishIdCard
    var reportIdCard = e.detail.value.reportIdCard
    var content = e.detail.value.content
    let msg = JSON.stringify({
      date: date,
      orderId: orderId,
      publishIdCard: publishIdCard,
      reportIdCard: reportIdCard,
      content: content
    })
    console.log("msg:",msg)
    wx.request({
      url: 'http://47.104.191.228:8085/report/post',
      method:"POST",
      header:{
        "Content-Type":"application/json"
      },
      data:{
        "date": date,
        "orderId": orderId,
        "publishIdCard": publishIdCard,
        "reportIdCard": reportIdCard,
        "content": content
      },
      success:function(res){
        console.log(res)
        wx.request({
          url: '成功',
        })
      }
    })
  }
})