// pages/index/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  login:function(e){
    console.log(e)
    var app = getApp()
    var phone = e.detail.value.phone
    var password = e.detail.value.password
    if(phone.length!=11){
      wx.showModal({
        title: '提示',
        content: '手机号输入错误！',
      })
    }
    if(password.length ==0){
      wx.showModal({
        title: '提示',
        content: '密码不能为空',
      })
    }
    if((phone.length==11)&&(password.length!=0)){
      wx.request({
        url: 'http://47.104.191.228:8085/student/login',
        method:'POST',
        data:{
          phone:phone,
          password:password
        },
        header:{
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        },
        success:function(e){
          console.log("成功",e)
          if(e.data!==""){
            app.globalData.userInfo = e.data
            console.log(app.globalData.userInfo)
            wx.switchTab({
              url: '../mine/mine',
            })
          }else{
            wx.showModal({
              title: '提示',
              content: '请先注册',
            })
          }
        }
      })
    }
  },
  myPage:function(e){
   wx.navigateTo({
     url: '../myPage/myPage',
   })
  },
  fgtpwd:function(e){
    wx.navigateTo({
      url: '../forget/forget',
    })
  }
})