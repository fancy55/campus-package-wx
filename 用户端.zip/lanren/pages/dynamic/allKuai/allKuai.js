// pages/dynamic/allKuai/allKuai.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    viewBtn: true,
    myKuaidi:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var app = getApp()
    var that = this
    var names = "月亮邮递员"//app.globalData.name
    var phones = "15873889873"//app.globalData.phone
    wx.request({
      url: 'http://47.104.191.228:8085/get/pack/all?name='+names+'&phone='+phones,
      method: 'GET',
      header: {
        'Content-Type': 'application/json'
      },
      success: function (res) {
        that.setData({
          myKuaidi: res.data.pack
        })
        console.log(res)
        console.log(res.data)
        console.log(res.data.pack)
      }
    })
  },
  erweima: function (e) {
    wx.navigateTo({
      url: '../erweima/erweima',
    })
  },
  release: function (e) {
    var orderId = this.data.kuaiDis.orderId
    var qpos = this.data.kuaiDis.qpos
    var realMaster = this.data.kuaiDis.realMaster
    var qPhone = this.data.kuaiDis.phone
    var qjm = this.data.kuaiDis.qjm
    var sstatus = this.data.kuaiDis.sstatus
    var getMaster = this.data.kuaiDis.getMaster
    if (sstatus == "yes") {
      wx.showModal({
        title: '提示',
        content: '该快递已发布',
      })
    }
    if (getMaster == null) {
      wx.navigateTo({
        url: '../release/release?orderId=' + orderId + '&qpos=' + qpos + '&realMaster=' + realMaster + '&qPhone=' + qPhone + '&qjm=' + qjm,
      })
    }
    else {
      wx.showModal({
        title: '提示',
        content: '该快递已有人代领',
      })
    }
  },
  refreshState: function (e) {
    var that = this
    var index = e.currentTarget.dataset.index
    var orderId = this.data.myKuaidi[index].orderId
    var sstatus = this.data.myKuaidi[index].sstatus
    console.log(e)
    if (sstatus == "yes") {
      wx.showModal({
        title: '提示',
        content: '已更新',
      })
    }
    else {
      wx.showModal({
        title: '提示',
        content: '确认已收到快递吗',
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
            console.log(orderId)
            wx.request({
              url: 'http://47.104.191.228:8085/update/status',
              method: "POST",
              header: { 'Content-Type': 'application/x-www-form-urlencoded' },
              data: {
                sStatus: "yes",
                orderId: orderId
              },
              dataType: "其他",
              success: function (res) {
                that.data.myKuaidi[index].sstatus = "yes"
                that.setData({
                  myKuaidi: that.data.myKuaidi
                })
              }
            })
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    }

  }
  ,
  lost: function (e) {
    wx.navigateTo({
      url: 'lost/lost',
    })
  }
})