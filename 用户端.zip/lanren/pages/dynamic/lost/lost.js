Page({
  data: {
    loading: false
  },
  myTime: function () {
    var time = new Date()
    var year = time.getFullYear()
    var month = time.getMonth() + 1
    var day = time.getDate()
    const formatNumber = n => {
      n = n.toString()
      return n[1] ? n : '0' + n
    }
    return [year, month, day].map(formatNumber).join('-')
  },
  formSubmit: function (e) {
    let _that = this;
    let orderId = this.data.orderId;
    let phone = e.detail.value.phone;
    let name = e.detail.value.name;
    let regPhone = /^1[3578]\d{9}$/;
    if (orderId == "" || phone == "" || name == "") {
      wx.showModal({
        title: '提示',
        content: '输入框中信息不能为空!',
      })
      return false
    }
    if ((!regPhone.test(phone))) { //验证手机号或者邮箱的其中一个对 这个关系饶了俩小时^_^
      wx.showModal({
        title: '提示',
        content: '您输入的手机号有误!',
      })
      return false
    } else {
      this.setData({
        loading: true
      })
      var lostpack=JSON.stringify({
        orderId:orderId,
        phone:phone,
        name:name,
        date:_that.myTime()
      })
      wx.request({
        url: 'http://47.104.191.228:8085/lost/post',
        header: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        },
        data: {
          msg: lostpack,
        },
        method: 'POST',
        success: function (res) {
          let status = res.data.status;
          if (status == 1) {
            _that.setData({
              loading: false,
            })
          }
          console.log("lost ok!")
        },
        fail: function () {
          console.log("意见反馈接口调用失败")
        },
        complete: function () {
          wx.navigateBack({
          })
        }
      })
    }
  },
  onLoad: function (options) {
    var orderId = options.orderId
    this.setData({
      orderId:orderId
    })
  }
})