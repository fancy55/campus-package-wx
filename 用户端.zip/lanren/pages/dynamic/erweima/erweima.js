// pages/dynamic/moreInfoPage/erweima/erweima.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    var orderId = options.orderId
    console.log(orderId)
    wx.request({
      url: 'http://47.104.191.228:8085/packC/ewm/qjm',
      header: {
        'content-type': 'application/json'
      },
      data: {
        'orderId': orderId
      },
      method: "GET",
      success: function (res) {
        console.log(res)
        that.setData({
          erweima:res.data
        })
      }
    })
  }
})