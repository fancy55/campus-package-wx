// pages/dynamic/release/release.js
var util = require("../../../utils/util.js")
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // input默认是1  
    num: 1,
    // 使用data数据对象设置样式名  
    minusStatus: 'disabled',
    date: '2016-09-01'
  },  

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var app = getApp()
    var userInfo = app.globalData.userInfo
    var orderId = options.orderId
    var qpos = options.qpos
    var sphone = options.sphone
    var qjm = options.qjm
    this.setData({
      orderId:orderId,
      qpos:qpos,
      sphone:sphone,
      qjm:qjm,
      nickname: userInfo.nickname,   //userInfo.nickname,"啦啦啦" 
      sidCard: userInfo.idCard,   //userInfo.idCard  "43132120001207576X"
      sPhoto:userInfo.photo
    })
  },
  bindDateChange:function(e){
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      endDate: e.detail.value
    })
  },
  submit: function(e){
    console.log(e)
    console.log(util.formatDate(new Date()))
    var endDate = this.data.endDate
    var sidCard = this.data.sidCard
    var sphoto = this.data.sPhoto
    console.log(sidCard)
    var value = e.detail.value
    wx.request({
      url: 'http://47.104.191.228:8085/publishPack/publish',
      method: "POST",
      header: {
        "content-type": "application/json"
      },
      data: {
        "sphoto":sphoto,
        "sidCard": sidCard,
        "endDate": endDate,
        "snickname": value.snickname,
        "spos": value.sPos,
        "orderId": value.orderId,
        "date": util.formatDate(new Date()),
        "description": value.kuai_info,
        "price": value.price,
        "category": "0"
      },

      success: function (res) {
        console.log(res)
        wx.showToast({
          title: '发布成功！',
          icon: 'success'
        })
        setTimeout(function () {
          wx.navigateBack({
            delta:1
          })
        }, 2000)
      },
      fail: function (res) {
        console.log(res)
      }
    })  
    },
  submitInfo: function(e){
    console.log(e)
   
  },
  /* 点击减号 */
  bindMinus: function () {
    var num = this.data.num;
    // 如果大于1时，才可以减  
    if (num > 1) {
      num--;
    }
    // 只有大于一件的时候，才能normal状态，否则disable状态  
    var minusStatus = num <= 1 ? 'disabled' : 'normal';
    // 将数值与状态写回  
    this.setData({
      num: num,
      minusStatus: minusStatus
    });
  },  
  /* 点击加号 */
  bindPlus: function () {
    var num = this.data.num;
    // 不作过多考虑自增1  
    num++;
    // 只有大于一件的时候，才能normal状态，否则disable状态  
    var minusStatus = num < 1 ? 'disabled' : 'normal';
    // 将数值与状态写回  
    this.setData({
      num: num,
      minusStatus: minusStatus
    });
  },  
  /* 输入框事件 */
  bindManual: function (e) {
    var num = e.detail.value;
    // 将数值与状态写回  
    this.setData({
      num: num
    });
  }
})
