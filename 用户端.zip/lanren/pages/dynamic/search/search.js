// pages/dynamic/search/search.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    state: "no",
    viewBtn: true,
    select: false,
    _function: '快递功能',
    viewCourier:false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  formSubmit:function (e) {
    var num = e.detail.value.num
    var that = this
    console.log(num)
    wx.request({
      url: 'http://47.104.191.228:8085/packC/get/one',
      method:"GET",
      data:{
        orderId:num
      },
      success: function(res){
        that.setData({
          kuaiDis: res.data//1160406830983
         
        })//430781200012120524
        var kuaiDis = that.data.kuaiDis
        console.log(kuaiDis)
        if(kuaiDis){
          that.setData({
            viewCourier:true
          })
        }
      }
    })
  },
  erweima: function (e) {
    wx.navigateTo({
      url: '../erweima/erweima',
    })
  },
  release: function (e) {
    var orderId = this.data.kuaiDis.orderId
    var qpos = this.data.kuaiDis.qpos
    var realMaster = this.data.kuaiDis.realMaster
    var qPhone = this.data.kuaiDis.phone
    var qjm = this.data.kuaiDis.qjm
    var sstatus = this.data.kuaiDis.sstatus
    var getMaster = this.data.kuaiDis.getMaster
    if (sstatus == "yes") {
      wx.showModal({
        title: '提示',
        content: '该快递已领取',
      })
    }
    if ((getMaster == "" || (getMaster == null)) && (sstatus == "no")) {
      wx.navigateTo({
        url: '../release/release?orderId=' + orderId + '&qpos=' + qpos + '&realMaster=' + realMaster + '&qPhone=' + qPhone + '&qjm=' + qjm,
      })
    }
    else {
      wx.showModal({
        title: '提示',
        content: '该快递已有人代领',
      })
    }
  },
  refreshState: function (e) {
    var that = this
    var sstatus = e.currentTarget.dataset.index
    console.log(e)
    if (sstatus == "yes") {
    }
    else {
      wx.showModal({
        title: '提示',
        content: '确认已收到快递吗',
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
            console.log(orderId)
            wx.request({
              url: 'http://47.104.191.228:8085/update/status',
              method: "POST",
              header: { 'Content-Type': 'application/x-www-form-urlencoded' },
              data: {
                sStatus: "yes",
                orderId: orderId
              },
              dataType: "其他",
              success: function (res) {
                that.data.myKuaidi[index].sstatus = "yes"
                that.setData({
                  myKuaidi: that.data.myKuaidi
                })
              }
            })
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    }

  }
  ,
  lost: function (e) {
    wx.navigateTo({
      url: 'lost/lost',
    })
  }
})