// pages/dynamic/dynamic.js

Page({

  /**
   * 页面的初始数据
   */
  data: {
    state: false,
    size:0,
    viewBtn: false,
    select: false,
    _function: '快递功能',
    login:false,
    isHide:true,
    kd_type: ["全部",  "待领取","代领"],
    selectedIndex:0,
    loadingShow:true,
    daiLingshow:false,
    qjm:false,
    selectQjm:10000
  },
  all: function (res) {
    wx.navigateTo({
      url: '../all/all',
    })
  },
 
  onLoad: function (options) {
 
  },
  newPage:function(e){
    var app = getApp()
    wx.navigateTo({
      url: 'search/search',
    })
  },
  published:function(e){
    wx.navigateTo({
      url: '../publish/publish',
    })
  },
  dlq:function(e){
    wx.navigateTo({
      url: '../dlq/dlq',
    })
  },
  mydl:function(e){
    wx.navigateTo({
      url: '../mydl/mydl',
    })
  },
  
 
})