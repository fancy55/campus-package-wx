// pages/forget/forget.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    password: "",
    pwdtrue: false,
    phone: ""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  getPwd: function (e) {
    console.log(e)
    this.setData({
      password: e.detail.value
    })
  },
  confirmPassword: function (e) {
    console.log(e)
    var repassword = e.detail.value
    var password = this.data.password
    if (password == repassword)
      this.setData({
        pwdtrue: false
      })
    else
      this.setData({
        pwdtrue: true
      })
  },
  inputNumber: function (e) {
    var phone = e.detail.value
    this.setData({
      phone: phone
    })
  },
  getNumber: function (e) {
    var phone = this.data.phone
    var that = this
    console.log(phone)
    wx.request({
      url: 'http://47.104.191.228:8085/send/' + phone,
      method: "get",
      header: {
        "Content-Type": "application/json;charset=UTF-8"
      },
      success: function (res) {
        console.log(res)
        that.setData({
          mycode: res.data.code
        })
      },
      fail: function (res) {
        console.log(res)
      }
    })
  },
  formSubmit: function (e) {
    console.log(e)
    var phone = e.detail.value.phone
    var password = e.detail.value.password
    var code = e.detail.value.code
    var mycode = this.data.mycode
    if (code == mycode)
      wx.request({
        url: 'http://47.104.191.228:8085/student/forget',
        method: "POST",
        data: {
          phone: phone,
          password: password,
        },
        header: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        },
        success: function (res) {
          console.log(res)
          wx.showToast({
            title: '修改成功',
          })
          setTimeout(function () {
            wx.navigateBack({
              delta: 1
            })
            wx.hideLoading()
          }, 2000)
        },
        fail: function (res) {
          console.log(res)
        }
      })
    else {
      wx.showModal({
        title: '提示',
        content: '验证码错误',
      })
    }
  }

})