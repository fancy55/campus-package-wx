//app.js
App({
  onLaunch: function () {
    // 展示本地存储能力
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

  },
  globalData: {
    userInfo: null,
    status:0
    // userStatus:"login",
    // name: "覃乐怡",//覃乐怡
    // phone: "15211019455",//15211019455
    // idCard: "430781200012120524"//430781200012120524
  }
})
