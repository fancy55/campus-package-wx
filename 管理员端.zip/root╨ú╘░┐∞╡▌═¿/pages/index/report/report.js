// pages/index/report/report.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    inputShowed: false,
    inputVal: "",
    list: [],
    user_list:[]
  },
  showInput: function () {
    this.setData({
      inputShowed: true
    });
  },
  hideInput: function () {
    this.setData({
      inputVal: "",
      inputShowed: false
    });
  },
  inputTyping: function (e) {
    this.setData({
      inputVal: e.detail.value
    });
  },
  searchById: function (e) {
    return new Promise(function (resolve, reject) {
      wx.request({
        url: 'http://47.104.191.228:8085/checkT/get/sb/report?reportIdCard=' + e,
        method: "GET",
        success: function (res) {
          console.log(res)
          resolve(res.data)
        },
        fail: function (res) {
          console.log("更新" + res.data.msg)
        }
      })
    })
  },
  searchInput: function () {
    var _this = this
    var inputVal = this.data.inputVal
    console.log(inputVal)
    this.searchById(inputVal).then((res) => {
      _this.hideInput()
      _this.setData({
        list:[],
        user_list: res,
        inputVal: "",
        inputShowed: false
      })
    })
  },
  searchAll: function () {
    var _this=this
    wx.request({
      url: 'http://47.104.191.228:8085/checkT/get/all/report',
      method: "GET",
      success: function (res) {
        console.log(res)
        _this.hideInput()
        _this.setData({
          "list": res.data,
          user_list:[]
        })
      },
      fail: function (res) {
        console.log(res.data.msg)
      }
    })
  },
  dealReport:function(e){
    var _this=this
    var report = JSON.stringify(e.currentTarget.dataset.report)
    console.log(e.currentTarget.dataset.report)
    wx.request({
      url: 'http://47.104.191.228:8085/checkT/deal/report',
      method: "POST",
      header:{
        "content-type":"application/json"
      },
      dataType:"JSON",
      data:report,
      success: function (res) {
        console.log(res)
        _this.onLoad()
      },
      fail: function (res) {
        console.log(res.data.msg)
      }
    })

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.searchAll()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})