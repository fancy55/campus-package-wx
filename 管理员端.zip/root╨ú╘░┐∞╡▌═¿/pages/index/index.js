//index.js
//获取应用实例
const app = getApp()
Page({
  data: {
    isHide: true,
    value: "" 
  },
  //事件处理函数
  formLogin:function(e){
    var _this=this
    var user = app.globalData.userInfo
    if (e.detail.value.name == user.name){
      if (e.detail.value.pwd == user.pwd){
        _this.setData({
          isHide: false
        })
      }else{
        wx.showToast({
          title: '密码错误，请重新输入!',
          icon: "none",
          duration: 2000
        })
        _this.setData({
          value: ""
        })
      } 
    }else{
      wx.showToast({
        title: '账号错误，请重新输入!',
        icon:"none",
        duration:2000
      })
      _this.setData({
        value: ""
      })
    }
  },
  toJiameng:function(){
    wx.navigateTo({
      url: './jiameng/jiameng',
    })
  },
  toReport:function(){
    wx.navigateTo({
      url: './report/report',
    })
  },
  toExit:function(){
    
  },
  onLoad: function () {
   
  }
})
