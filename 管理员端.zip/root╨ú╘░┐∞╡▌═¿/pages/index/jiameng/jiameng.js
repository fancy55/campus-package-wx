// pages/index/jiameng/jiameng.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    array:["所有申请","已通过申请","审核中申请"],
    index:0,
    list:[],
    run:false
  },
  bindPickerChange:function(e){
    var _this=this
    if(e.detail.value==0){
      _this.getAll()
    } else if (e.detail.value == 1){
      _this.getPass()
    }else{
      _this.getRun()
    }
    this.setData({
      index:e.detail.value
    })
  },
  getAll:function(){
    var _this=this
    wx.request({
      url: 'http://47.104.191.228:8085/checkT/get/all/certification',
      method:'get',
      dataType:"json",
      header:{
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
      },
      success: function (res) {
        console.log(res)
        if (res.data.length == 0) {
          wx.showToast({
            title: '暂无数据！',
            icon:"none",
            duration:2000
          })
        }
        _this.setData({
          list:res.data,
          run: false
        })
      },
      fail: function (res) {
        console.log("失败")
      }
    })
  },
  getPass: function () {
    var _this = this
    wx.request({
      url: 'http://47.104.191.228:8085/checkT/get/ed/certification',
      method: 'get',
      dataType: "json",
      header: {
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
      },
      success: function (res) {
        console.log(res)
        if (res.data.length == 0) {
          wx.showToast({
            title: '暂无数据！',
            icon: "none",
            duration: 2000
          })
        }
        _this.setData({
          list: res.data,
          run:false
        })
      },
      fail: function (res) {
        console.log("失败")
      }
    })
  },
  getRun: function () {
    var _this = this
    wx.request({
      url: 'http://47.104.191.228:8085/checkT/get/ing/certification',
      method: 'get',
      dataType: "json",
      header: {
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
      },
      success: function (res) {
        console.log(res)
        if(res.data.length==0){
          wx.showToast({
            title: '暂无数据！',
            icon: "none",
            duration: 2000
          })
        }
        _this.setData({
          list: res.data,
          run:true
        })
      },
      fail: function (res) {
        console.log("失败")
      }
    })
  },
  myTime: function () {
    var time = new Date()
    var year = time.getFullYear()
    var month = time.getMonth() + 1
    var day = time.getDate()
    const formatNumber = n => {
      n = n.toString()
      return n[1] ? n : '0' + n
    }
    return [year, month, day].map(formatNumber).join('-')
  },
  refuse:function(e){
    console.log(e)
    var _this = this
    var idCard=e.currentTarget.dataset.id
    var pDate=this.myTime()
    wx.request({
      url: 'http://47.104.191.228:8085/checkT/not/pass/check?pDate='+pDate+'&idCard='+idCard,
      method:"POST",
      success: function (res) {
        console.log(res)
        _this.getRun()
      },
      fail: function (res) {
        console.log("失败")
      }
    })
  },
  pass: function (e) {
    console.log(e)
    var _this=this
    var idCard = e.currentTarget.dataset.id
    var pDate = this.myTime()
    wx.request({
      url: 'http://47.104.191.228:8085/checkT/pass/check?pDate=' + pDate + '&idCard=' + idCard,
      method: "POST",
      success: function (res) {
        console.log(res)
        _this.getRun()
      },
      fail: function (res) {
        console.log("失败")
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getAll()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})