//app.js
App({
  globalData: {
    userInfo:{
      name:"root",
      pwd:"123456abc"
    }
  }
})