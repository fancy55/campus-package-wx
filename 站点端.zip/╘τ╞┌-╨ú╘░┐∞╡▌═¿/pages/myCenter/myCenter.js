// pages/myCenter/myCenter.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
    login_result:false,
    isHide:true,
    name:""
  },
  bindGetUserInfo:function(res){
    console.log(res)
    var _this=this
    if(!this.data.login_result){
      if (res.detail.userInfo) {
        //用户按了允许授权按钮
        // 获取到用户的信息了，打印到控制台上看下
        console.log("用户的信息如下：");
        console.log(res.detail.userInfo);
        //授权成功后,通过改变 isHide 的值，让实现页面显示出来，把授权页面隐藏起来
        _this.setData({
          isHide: false,
          login_result:true
        });
      } else {
        //用户按了拒绝按钮
        wx.showModal({
          title: '警告',
          content: '您点击了拒绝授权，将无法进入小程序，请授权之后再进入!!!',
          showCancel: false,
          confirmText: '返回授权',
          success: function(res){
            // 用户没有授权成功，不需要改变 isHide 的值
            if (res.confirm) {
              console.log('用户点击了“返回授权”');
            }
          }
        })  
      }
    }
  },
  close:function(){
    this.setData({
      "isHide":true
    })
  },
  getidCard:function(e){
    var app=getApp()
    app.globalData.idCard=e.detail.value
  },
  getname: function (e) {
    this.setData({
      name: e.detail.value
    })
  },
  personLogin: function (e) {
    console.log(e)
    return new Promise(function (resolve, reject) {
      wx.request({
        url: 'http://www.qlybit.xyz:8082/login',
        method: "POST",
        header: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        },
        data: {
          person: e
        },
        dataType: "JSON",
        success: function (res) {
          resolve(res)
          console.log(res)
        },
        fail: function (res) {
          console.log("更新" + res.data.msg)
        }
      })
    })
  },
  login:function(){
    var _this=this
    var app = getApp();
    var idCard = app.globalData.idCard
    var person = JSON.stringify({
      name: _this.data.name,
      idCard: idCard
    })
    this.personLogin(person).then((res) => {
      console.log(res.data)
      console.log(res.data == "用户为空")
      if (res.data == "用户为空") {
        app.globalData.userStatus = "notRegistered"
        _this.setData({
          isHide: true,
        })
      } else {
        app.globalData.userStatus = "login"
        _this.setData({
          isHide: true,
        })
        this.onLoad()
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _this = this;
    var app = getApp();     // 取得全局App
    console.log(app.globalData.userStatus)
    if (app.globalData.userStatus == "notLogin") {
      _this.setData({
        "login_result": false
      })
    } else{
      _this.setData({
        "login_result": true
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.onLoad()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})