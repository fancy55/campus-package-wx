// pages/myCenter/myInformation/myInformation.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    user:{}
  },
  replenish_information:function(){
    wx.navigateTo({
      url: '../replenishInformation/replenishInformation',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  getInfo:function(e){
    console.log(e)
    return new Promise(function (resolve, reject){
      wx.request({
        url: 'http://www.qlybit.xyz:8082/getInfo?idCard='+e,
        method: "POST",
        header: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        },
        success: function (res) {
          resolve(res)
          console.log(res)
        },
        fail: function (res) {
          console.log("更新" + res.data.msg)
        }
      })
    })  
  },
  onLoad: function (options) {
    var _this=this
    var app=getApp()
    var idCard=app.globalData.idCard
    this.getInfo(idCard).then((res)=>{
      _this.setData({
        "user":res.data.userInfo
      })
      console.log(_this.data.user)
    }) 
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.onLoad()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})