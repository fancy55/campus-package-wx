// pages/myCenter/replenishInformation/replenishInformation.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    result:null,
    phone:'',
    date:'1999-10-01',
    rightcode:true,
    notcode:true,
    isphone:true,
    code:"em",
    sexs:["男","女"],
    sexIndex: 0,
    update:false
  },
  getSex:function(e){
    var sexs=this.data.sexs
    this.setData({
      sexIndex: e.detail.value,   
    })
  },
  isphone:function(e){
    console.log(e)
    var _this=this
    if(e.length!=11){
      _this.setData({
        "isphone":false
      })
    }else{
      _this.setData({
        "isphone":true,
      })
    }
    console.log(this.data.isphone)
  },
  getPhone:function(e){
    this.setData({
      "phone":e.detail.value
    })
  },
  getDate:function(e){
    this.setData({
      "date":e.detail.value
    })
  },
  codeInput:function(e){
    var _this=this
    var inputCode=e.detail.value
    var code=this.data.code
    console.log(inputCode+" "+code)
    console.log(inputCode==code)
    if(inputCode==code){
      _this.setData({
        "rightcode":true,
        "notcode": false
      })
      console.log(_this.data.notcode)
    }else{
      _this.setData({
        "rightcode":false,
      })
    }
  },
  getCode:function(){
    var _this=this
    if(this.data.result==null){
      var phone=this.data.phone
    }else{
      var phone=this.data.result.phone
    }
    this.isphone(phone)
    console.log(this.data.isphone)
    if(this.data.isphone){
      wx.request({
        url: 'http://www.qlybit.xyz:8082/sms/send/'+phone,
        method: "GET",
        header: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        },
        success: function (res) {
          console.log(res)
          var list=res.data.data.split(',')
          var code=list[0].slice(5)
          console.log(code)
          _this.setData({
            "code":code
          })
          console.log(_this.data.code)
        },
        fail: function (res) {
          console.log(res.data.msg)
        }
      })
    }
  },
  formSubmit:function(e){
    var _this=this
    var user=e.detail.value
    var update=this.data.update
    if(!update){
      if(user.sex!=1){
        user.sex="女"
      }else if(user.sex==0){
        user.sex="男"
      }
    }
    var person=JSON.stringify(user)
    console.log(_this.data.notcode)
    if(!_this.data.notcode){
      if (update) {
        wx.request({
          url: "http://www.qlybit.xyz:8082/updateInfo",
          method: "POST",
          dataType: "json",
          data: {
            msg: person
          },
          header: {
            "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
          },
          success: function (res) {
            console.log(res)
            var app=getApp()
            app.globalData.userStatus="login"
            app.globalData.idCard=user.idCard
            console.log(app.globalData.idCard)
            wx.navigateTo({ url: '../../scan/success/success?result=用户信息已完善' })
          },
          fail: function (res) {
            console.log("更新" + res.data.msg)
          }
        })
      } else {
        wx.request({
          url: 'http://www.qlybit.xyz:8082/register',
          method: "POST",
          dataType: "json",
          data: {
            person: person
          },
          header: {
            "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
          },
          success: function (res) {
            console.log(res)
            var app=getApp()
            app.globalData.userStatus="login"
            app.globalData.idCard=user.idCard
            console.log(app.globalData.idCard)
            wx.navigateTo({ url: '../../scan/success/success?result=用户信息已完善' })
          },
          fail: function (res) {
            console.log("更新" + res.data.msg)
          }
        })
      }
    }
  },
  getInfo:function(e){
    console.log(e)
    return new Promise(function (resolve, reject){
      wx.request({
        url: 'http://www.qlybit.xyz:8082/getInfo?idCard='+e,
        method: "POST",
        header: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        },
        success: function (res) {
          resolve(res)
          console.log(res)
        },
        fail: function (res) {
          console.log("更新" + res.data.msg)
        }
      })
    })  
  }, 
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _this=this
    var app=getApp()
    var idCard=app.globalData.idCard
    this.getInfo(idCard).then((res)=>{
      if(res.data.userInfo!=null){
        _this.setData({
          "result":res.data.userInfo,
          "date":res.data.userInfo.date,
          "update":true
        })
      }
      console.log(_this.data.result)
    }) 
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.onLoad()
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})