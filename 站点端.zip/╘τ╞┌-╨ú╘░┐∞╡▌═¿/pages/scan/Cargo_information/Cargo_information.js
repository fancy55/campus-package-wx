// pages/scan/Cargo_information/Cargo_information.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    express:{
      no:"",
      realM:"",
      phone:"",
      get_position:"弘二"
    },
    accounts: ["弘二", "天天超市二楼", "益和堂后门","天天超市后面","妈妈驿站"],
    accountIndex: 0
  },
  getPosition: function(e) {
    var accounts=this.data.accounts
    this.setData({
        accountIndex: e.detail.value,
      "express.get_position": accounts[e.detail.value]   
    })
    console.log(this.data.express.get_position);
  },
  update:function(){
    var _this=this
    var express=this.myExpress()
    console.log(express)
    let newDate = {
      msg: JSON.stringify(express)
    }
    wx.request({
      url: 'http://www.qlybit.xyz:8082/pack',
      method: "POST",
      dataType: "json",
      data: {
        msg: newDate.msg
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
      },
      success: function (res) {
        wx.navigateTo({
          url: '../success/success?result=快递信息已更新完毕'
        })
        console.log("更新成功")
        console.log(res)
      },
      fail: function (res) {
        console.log("更新失败")
        console.log(res)
      }
    })
    console.log("133")
  },
  myTime: function(){
    var time = new Date()
    var year=time.getFullYear()
    var month=time.getMonth()+1
    var day=time.getDate()
    const formatNumber = n => {
      n = n.toString()
      return n[1] ? n : '0' + n
    }
    return [year, month, day].map(formatNumber).join('-')
  },
  myExpress:function(){
    var expressInfo = this.data.express
    var express={
      orderID:expressInfo.no,
      realMaster: expressInfo.realM,
      phone: expressInfo.phone,
      qPos: expressInfo.get_position,
      sPos:"",
      content:"货物",
      qStatus: "no",
      sStatus: 'no',
      date:this.myTime()
    }
    console.log(express)
    return express
  },
  getExpressInfo: function (result) {
    console.log("data:"+result.no)
    return new Promise(function(resolve,reject){
      wx.request({
        url: 'https://cexpress.market.alicloudapi.com/cexpress', //【1】仅为示例，并非真实的接口地址
        method: 'GET',								   //【2】需要修改为对应的GET 或者 POST 方法
        header: {
          "Authorization": "APPCODE de4f081d7c1140148bf4fcc8024bdb30"  //【3】传入自己的appcode，在买家中心查看。注意appcode与值之间有一个必须的空格 58ac025da**********3341f029ce  改为自己的APPCODE
        },
        data: {  //【4】仅为示例，传入实际的相关参数 ，data数组里的参数可参考产品详情
          type: "",
          no: result.no
        },
        // 【1】~ 【4】 许要修改成对应的，区分大小写！
        success: function (res) {
          resolve(res.data)         //cb(res.data);
        }
      })
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var result = JSON.parse(options.result)
    console.log("type："+result.type+"no:"+result.no)
    this.getExpressInfo(result).then((res)=>{
      var express = res
      console.log(express)    //多线程
      this.setData({
        "express.no": express.no,
        "express.realM": express.courier,
        "express.phone": express.courierPhone
      })
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})