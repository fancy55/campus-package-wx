Page({

  /**
   * 页面的初始数据
   */
  data: {
    inputShowed: false,
    inputVal: "",
    real_timeSearch:[],
    list:[],
    bnrUrl: [{
      url: "../../img/ad1.png"
    }, {
      url: "../../img/ad2.png"
    }, {
      url: "../../img/ad3.png"
    }, {
      url: "../../img/ad4.png"
    }],
    result: "",
    login: false,
    isHide:true,
    name:""
  },
  myTime: function(){
    var time = new Date()
    var year=time.getFullYear()
    var month=time.getMonth()+1
    var day=time.getDate()
    const formatNumber = n => {
      n = n.toString()
      return n[1] ? n : '0' + n
    }
    return [year, month, day].map(formatNumber).join('-')
  },
  realTime: function(today,addDayCount){
    var time;
    if(today){
      time = new Date(today);
    }else{
      time = new Date();
    }
    time.setDate(time.getDate() + addDayCount);//获取AddDayCount天后的日期
    var year=time.getFullYear()
    var month=time.getMonth()+1
    var day=time.getDate()
    const formatNumber = n => {
      n = n.toString()
      return n[1] ? n : '0' + n
    }
    return [year, month, day].map(formatNumber).join('-')
  },
  showInput: function () {
      this.setData({
          inputShowed: true
      });
  },
  hideInput: function () {
      this.setData({
          inputVal: "",
          inputShowed: false
      });
  },
  inputTyping: function (e) {
      this.setData({
          inputVal: e.detail.value
      });
  },
  bindGetUserInfo:function(res){
    var _this=this
    if(this.data.result=="登录"){
      if (res.detail.userInfo) {
        //用户按了允许授权按钮
        // 获取到用户的信息了，打印到控制台上看下
        console.log("用户的信息如下：");
        console.log(res.detail.userInfo);
        //授权成功后,通过改变 isHide 的值，让实现页面显示出来，把授权页面隐藏起来
        _this.setData({
          isHide: false
        });
      } else {
        //用户按了拒绝按钮
        wx.showModal({
          title: '警告',
          content: '您点击了拒绝授权，将无法进入小程序，请授权之后再进入!!!',
          showCancel: false,
          confirmText: '返回授权',
          success: function(res){
            // 用户没有授权成功，不需要改变 isHide 的值
            if (res.confirm) {
              console.log('用户点击了“返回授权”');
            }
          }
        })  
      }
    }else{
      this.register()
    }
  },
  close:function(){
    this.setData({
      "isHide":true
    })
  },
  getidCard:function(e){
    var app=getApp()
    app.globalData.idCard=e.detail.value
  },
  getname: function (e) {
    this.setData({
      name: e.detail.value
    })   
  },
  login:function(){
    var _this=this
    var app = getApp();
    var idCard=app.globalData.idCard
    var person=JSON.stringify({
      name:_this.data.name,
      idCard:idCard
    })
    this.personLogin(person).then((res)=>{
      console.log(res.data)
      console.log(res.data=="用户为空")
      if (res.data == "用户为空"){
        app.globalData.userStatus="notRegistered"
        _this.setData({
          isHide:true,
        })
        this.onLoad()
      }else{
        app.globalData.userStatus="login"
        _this.setData({
          isHide:true,
        })
        this.onLoad()
      }
    })
  },
  personLogin:function(e){
    console.log(e)
    return new Promise(function (resolve, reject){
      wx.request({
        url: 'http://www.qlybit.xyz:8082/login',
        method: "POST",
        header: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        },
        data: {
          person: e
        },
        dataType: "JSON",
        success: function (res) {
          resolve(res)
          console.log(res)
        },
        fail: function (res) {
          console.log("更新" + res.data.msg)
        }
      })
    })  
  },
  register:function(){
    wx.navigateTo({
      url: '../myCenter/replenishInformation/replenishInformation',
    })
  },
  searchByDate:function(e){
    return new Promise(function(resolve,reject){
      wx.request({
        url: 'http://www.qlybit.xyz:8082/date?date='+e,
        method: "GET",
        success: function (res) {
          console.log(res)
          resolve(res.data)
        },
        fail: function (res) {
          console.log("更新" + res.data.msg)
        }
      })
    })
  },
  searchInput:function(){
    var _this=this
    var inputVal=this.data.inputVal
    console.log(inputVal)
    this.searchByDate(inputVal).then((res)=>{
      _this.hideInput()
      _this.setData({
        "list":res.pack,
        inputVal: "",
        inputShowed: false
      })
    })
  },
  search:function(e){
    var msg=e.currentTarget.dataset.value
    var _this=this
    this.searchByDate(msg).then((res)=>{
      _this.setData({
        "list":res.pack,
        inputVal: "",
        inputShowed: false
      })
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _this=this;
    var app = getApp();     // 取得全局App
    console.log(app.globalData.userStatus)
    if (app.globalData.userStatus == "notLogin") {
      _this.setData({
        "result": "登录"
      })
    } else if (app.globalData.userStatus == "notRegistered") {
      _this.setData({
        "result": "完善信息"
      })
    } else {
      _this.setData({
        "login": true,
        "real_timeSearch[0]": _this.realTime(new Date(), 0),
        "real_timeSearch[1]": _this.realTime(new Date(), -1),
        "real_timeSearch[2]": _this.realTime(new Date(), -2),
        "real_timeSearch[3]": _this.realTime(new Date(), -3)
      })
      var time = _this.myTime()
      _this.searchByDate(time).then((res) => {
        console.log(res)
        _this.setData({
          "list": res.pack
        })
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.onLoad()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})